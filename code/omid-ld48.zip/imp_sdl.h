#pragma once
#pragma clang system_header
#include <SDL.h>
#include <SDL_audio.h>
#include <SDL_ttf.h>
